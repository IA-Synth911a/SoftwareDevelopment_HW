package com.example.demo.service;

import com.example.demo.database.Sql2oDbHandler;
import com.example.demo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.sql2o.Connection;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private Sql2oDbHandler sql2oDbHandler;

    public UserService() {

    }

    public List<User> getUsers() {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "select ID id, Email email, First_Name firstName, Last_Name LastName, Password password"
                + " from USER";
    
        return connection.createQuery(query).executeAndFetch(User.class);
        }
    }

    public List<User> getUsers(String keyword) {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "select ID id, Email email, First_Name firstName, Last_Name LastName, Password password"
                + " from USER where name like :keyword";
    
        return connection.createQuery(query)
            .addParameter("keyword", "%"+keyword+"%")
            .executeAndFetch(User.class);
        }
    }

    public void setUser() {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "INSERT INTO Team14.USER(Email, First_Name, Last_Name, Password)"
                + " VALUES('test@mail.com', 'Just', 'Test', 'passWord123')";
        
            connection.createQuery(query).executeUpdate();
        }
    }

    public void setUser(String E_mail, String First, String Last, String passWord) {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "INSERT INTO Team14.USER(Email, First_Name, Last_Name, Password)"
                + " VALUES(:E_mail, :First, :Last, :passWord)";
        
            connection.createQuery(query).addParameter("E_mail", "%"+E_mail+"%").addParameter("First", "%"+First+"%").addParameter("Last", "%"+Last+"%").addParameter("passWord", "%"+passWord+"%").executeUpdate();
        }
    }
}
