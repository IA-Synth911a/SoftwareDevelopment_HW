package com.example.demo.controller;

import com.example.demo.model.Transaction;
import com.example.demo.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TransactionController {
    
    @Autowired
    TransactionService transactionManager;

    @GetMapping("/borrowPage")
    public List<Transaction> showBorrowPage(Model model) {
        model.addAttribute("bUserName", new String());
        model.addAttribute("bBookId", new String());
        return transactionManager.getTransaction();
    }

    @PostMapping("/borrowPage")
    public void showBorrowPage(@ModelAttribute("bUserName") String UserName, @ModelAttribute("bBookId") String BookId) {
        transactionManager.setTransaction(UserName, BookId);
        //transactionManager.setTransaction();
    }

    @GetMapping("/returnPage")
    public List<Transaction> showReturnPage(Model model) {
        model.addAttribute("rUserName", new String());
        model.addAttribute("rBookId", new String());
        return transactionManager.getTransaction();
    }

    @PostMapping("/returnPage")
    public void showReturnPage(@ModelAttribute("rUserName") String UserName, @ModelAttribute("rBookId") String BookId) {
        transactionManager.setTransaction(UserName, BookId);
    }
}
