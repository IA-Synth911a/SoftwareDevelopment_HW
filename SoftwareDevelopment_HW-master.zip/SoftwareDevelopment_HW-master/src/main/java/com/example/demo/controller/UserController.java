package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserController {
    
    @Autowired
    UserService userManager;

    @GetMapping("/registerPage")
    public List<User> showRegisterPage(Model model) {
        model.addAttribute("rEmail", new String());
        model.addAttribute("rPassword", new String());
        model.addAttribute("rFirstName", new String());
        model.addAttribute("rLastName", new String());
        return userManager.getUsers();
    }

    @PostMapping("/registerPage")
    public void showBorrowPage(@ModelAttribute("rEmail") String e_mail, @ModelAttribute("rFirstName") String first_name,  @ModelAttribute("rLastName") String last_name,  @ModelAttribute("rPassword") String password) {
        userManager.setUser(e_mail, first_name, last_name, password);
    }
}
