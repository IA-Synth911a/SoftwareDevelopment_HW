package com.example.demo.model;

public class Transaction {
    private long id;
    private long user_id;
    private long book_id;

    public Transaction() {
    }
  
    public Transaction(long id, long user_id, long book_id) {
        this.id = id;
        this.user_id = user_id;
        this.book_id = book_id;
    }

    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return user_id;
    }
    
    public void setUserId(long user_id) {
        this.user_id = user_id;
    }

    public long getBookId() {
        return book_id;
    }
    
    public void setBookId(long book_id) {
        this.book_id = book_id;
    }
}
