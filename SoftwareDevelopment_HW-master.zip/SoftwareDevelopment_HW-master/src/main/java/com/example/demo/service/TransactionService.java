package com.example.demo.service;

import com.example.demo.database.Sql2oDbHandler;
import com.example.demo.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.sql2o.Connection;

import java.util.List;

@Service
public class TransactionService {
    
    @Autowired
    private Sql2oDbHandler sql2oDbHandler;

    public TransactionService() {

    }

    public List<Transaction> getTransaction() {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "select USER_ID user_id, BOOK_ID book_id from Transaction";
        
        return connection.createQuery(query).executeAndFetch(Transaction.class);
        }
    }

    public void setTransaction() {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "INSERT INTO Team14.USER(USER_ID, BOOK_ID)"
                + " VALUES('123@mail.com', 'E050118774')";
        
        connection.createQuery(query).executeUpdate();
        }
    }

    public void setTransaction(String userName, String bookId) {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "INSERT INTO Team14.USER(USER_ID, BOOK_ID)"
                + " VALUES(:u_Id, :b_Id)";
        
        connection.createQuery(query).addParameter("u_Id", "%"+userName+"%").addParameter("b_Id", "%"+bookId+"%").executeUpdate();
        }
    }

    public void deleteTransaction() {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "DELETE FROM Team14.USER WHERE USER_ID = '123@mail.com' AND BOOK_ID = 'E050118774'";
        
        connection.createQuery(query).executeUpdate();
        }
    }

    public void deleteTransaction(String userName, String bookId) {
        try (Connection connection = sql2oDbHandler.getConnector().open()) {
            String query = "DELETE FROM Team14.USER WHERE USER_ID = :u_Id and BOOK_ID = :b_Id";
        
        connection.createQuery(query).addParameter("u_Id", "%"+userName+"%").addParameter("b_Id", "%"+bookId+"%").executeUpdate();
        }
    }
}
